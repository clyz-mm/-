package java_win.copy;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.*;

public class ChooserCouWin extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel labelStu;
	JLabel labelCou;
	JTextField textFieldStu;
	JTextField textFieldCou;
	JButton button;
	JButton buttonGx;

	public ChooserCouWin() {
		// TODO Auto-generated constructor stub
		setTitle("ѧ��ѡ��");
		setVisible(true);
		setBounds(500, 200, 800, 600);
		init();
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	}

	void updateCou() {
		sql sql = new sql();
		Statement statement = sql.getStatement();

		String[] Counum = new String[100];
		String[] Stunum = new String[100];
		int[] pel = new int[100];
		int i = 0;
		int j = 0;
		try {
			ResultSet strCou = statement.executeQuery("select * from couinfo");
			while (strCou.next()) {
				Counum[i++] = strCou.getString("�γ̴���").trim();
			}
			strCou.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			ResultSet strStu = statement.executeQuery("select * from stuinfo");
			while (strStu.next()) {
				Stunum[j++] = strStu.getString("��ѡ�γ�").trim();
			}
			strStu.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int j2 = 0; j2 < i; j2++) {
			for (int k = 0; k < j; k++) {
				if (Counum[j2].equals(Stunum[k])) {
					pel[j2]++;
				}
			}
		}
		try {

			for (int k = 0; k < i; k++) {
				String update = "update couinfo set ѡ������=C where �γ̴���=S";
				String num = String.valueOf(pel[k]);
				String code = Counum[k];
				update = update.replaceAll("C", num);
				update = update.replaceAll("S", code);
				statement.execute(update);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.err.println("����ʧ��");
		}
	}

	void init() {
		setLayout(new FlowLayout());

		labelCou = new JLabel("��ѡ�γ̴��룺");
		labelStu = new JLabel("ѡ��ѧ�ţ�");
		textFieldCou = new JTextField(10);
		textFieldStu = new JTextField(10);
		button = new JButton("ȷ��");
		add(labelStu);
		add(textFieldStu);
		add(labelCou);
		add(textFieldCou);
		add(button);

		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				sql sql = new sql();
				Statement statement = sql.getStatement();
				String update = "update stuinfo set ��ѡ�γ�=c where ѧ��=S";
				String StuNum = textFieldStu.getText().toString().trim();
				String CouNum = textFieldCou.getText().toString().trim();
				try {

					if (!sql.isPKCou(CouNum) && !sql.isPK(StuNum)) {
						CouNum = "'" + CouNum + "'";
						StuNum = "'" + StuNum + "'";
						update = update.replaceAll("c", CouNum);
						update = update.replaceAll("S", StuNum);
						System.out.println(update);
						statement.executeUpdate(update);

						JOptionPane.showMessageDialog(null, "ѡ�γɹ�", "��ʾ", JOptionPane.WARNING_MESSAGE);
						updateCou();
					} else {
						JOptionPane.showMessageDialog(null, "�γ̻�ѧ�Ų����ڣ�ѡ��ʧ��", "��ʾ", JOptionPane.WARNING_MESSAGE);
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.err.println("ѡ��д�����");
				}
			}
		});
	}

}
