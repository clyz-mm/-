package java_win.copy;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileSystemView;

public class FileChooserWin {

	String getOpenPath() {
		String path;
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setCurrentDirectory(FileSystemView.getFileSystemView().getHomeDirectory());
		fileChooser.setDialogTitle("�ϴ��ļ�");
		fileChooser.setApproveButtonText("ȷ��");
		int result = fileChooser.showOpenDialog(null);// ����ѡ���ļ����ļ�ѡ�񴰿�
		if (JFileChooser.APPROVE_OPTION == result) {
			path = fileChooser.getSelectedFile().getPath();
			// System.out.println(path);
			return path;
		}
		return null;
	}

	String getSavePath() {
		String path;
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setCurrentDirectory(FileSystemView.getFileSystemView().getHomeDirectory());
		fileChooser.setDialogTitle("�����ļ�");
		fileChooser.setApproveButtonText("����");
		int result = fileChooser.showSaveDialog(null);// ���������ļ����ļ�ѡ�񴰿�
		if (JFileChooser.APPROVE_OPTION == result) {
			path = fileChooser.getSelectedFile().getPath();
			// System.out.println(path);
			return path;
		}
		return null;
	}
}
