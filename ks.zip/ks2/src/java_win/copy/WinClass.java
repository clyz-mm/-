package java_win.copy;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class WinClass extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton button1;//����
	JTextField textField1;
	JPasswordField textField2;
	JLabel label1;
	JLabel label2;
	JLabel title;
	public WinClass() {
		setTitle("��¼");
		setBounds(500, 200, 800, 600);
		init();//��ʼ��
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	void init() {
		setLayout(null);
		button1 = new JButton("��¼");
		textField1 = new JTextField();
		textField2 = new JPasswordField();
		label1 = new JLabel("�û���:");
		label2 = new JLabel("��  ��:");
		title = new JLabel("ѧ �� ѡ �� �� �� ϵ ͳ");

		button1.setFont(new Font("����", Font.BOLD, 17));
		label1.setFont(new Font("����", Font.BOLD, 17));
		label2.setFont(new Font("����", Font.BOLD, 17));
		title.setFont(new Font("����", Font.BOLD, 30));

		add(textField1);
		add(textField2);
		add(button1);
		add(label1);
		add(label2);
		add(title);
//���ø��������λ��
		button1.setBounds(355, 350, 70, 30);
		title.setBounds(200, 100, 380, 80);
		label1.setBounds(255, 250, 70, 30);
		label2.setBounds(255, 295, 70, 30);
		textField1.setBounds(330, 250, 120, 35);
		textField2.setBounds(330, 295, 120, 35);
//Ϊ������Ӽ�����
		textField1.addActionListener(this);
		textField2.addActionListener(this);
		button1.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String users = textField1.getText();
		String passwords = String.valueOf(textField2.getPassword());
		sql user_info = new sql();
		if (user_info.isUser(users, passwords)) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			this.dispose();
			new WinLogin();

		} else {
			JOptionPane.showMessageDialog(this, "�û����������������", "��¼ʧ��", JOptionPane.WARNING_MESSAGE);
		}
	}
}
