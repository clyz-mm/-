package java_win.copy;

import java.awt.Font;
import java.awt.Panel;
import java.awt.event.*;

import javax.swing.*;

public class WinLogin extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	boolean exitWin = false;
	JMenuBar menuBar;
	Panel menu;
	JMenu menu2;

	JMenuItem menuExit;
	JButton menuAdd;// ���ӿγ̺�ѧ����Ϣ
	JButton menuSearch;// ��ѯ
	JButton menuShow;// ��ʾ
	JButton menuChooserCou;// ѡ��
	JButton menuCount;// ͳ��
	JButton menuSave;// ����
	JButton menuImport;// ����

	JTextArea area;

	public WinLogin() {
		// TODO Auto-generated constructor stub
		setTitle("����");
		setBounds(500, 200, 800, 600);
		init();
		item();
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	void init() {
		menuBar = new JMenuBar();
		menu = new Panel();
		menu2 = new JMenu("�˵�");
		menuExit = new JMenuItem("�˳�");

		menuAdd = new JButton("������Ϣ");
		menuSearch = new JButton("��ѯ/�༭");
		menuShow = new JButton("��ʾ/ɾ��");
		menuChooserCou = new JButton("ѧ��ѡ��");
		menuCount = new JButton("ͳ����Ϣ");
		menuSave = new JButton("������Ϣ");
		menuImport = new JButton("������Ϣ");
		area = new JTextArea();

		setJMenuBar(menuBar);
		menu.setLayout(null);
		menu.setVisible(true);
		this.add(menu);

		menu2.add(menuExit);

		menuAdd.setBounds(320, 80, 150, 40);
		menuSearch.setBounds(320, 130, 150, 40);
		menuShow.setBounds(320, 180, 150, 40);
		menuChooserCou.setBounds(320, 280, 150, 40);
		menuCount.setBounds(320, 330, 150, 40);
		menuSave.setBounds(320, 380, 150, 40);
		menuImport.setBounds(320, 430, 150, 40);

		menuAdd.setFont(new Font("����", Font.BOLD, 20));
		menuCount.setFont(new Font("����", Font.BOLD, 20));
		menuChooserCou.setFont(new Font("����", Font.BOLD, 20));
		menuImport.setFont(new Font("����", Font.BOLD, 20));
		menuSave.setFont(new Font("����", Font.BOLD, 20));
		menuSearch.setFont(new Font("����", Font.BOLD, 20));
		menuShow.setFont(new Font("����", Font.BOLD, 20));

		menu.add(menuAdd);
		menu.add(menuSearch);
		menu.add(menuShow);
		menu.add(menuChooserCou);
		menu.add(menuCount);
		menu.add(menuSave);
		menu.add(menuImport);
		menu.add(menu2);
		menuBar.add(menu2);

	}

	void item() {
		menuAdd.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new addWin();
			}
		});

		menuSearch.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new searchWin();
			}
		});

		menuShow.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new showWin();

			}
		});

		menuCount.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new countWin();

			}
		});

		menuSave.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new saveWin();// �̳�showWin��
			}
		});

		menuImport.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new importWin();

			}
		});

		menuExit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});
		menuChooserCou.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				new ChooserCouWin();
			}
		});
	}

}
