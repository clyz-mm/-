package java_win.copy;

import java.awt.event.*;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class addWin extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	JTable table;
	DefaultTableModel model;

	JButton buttonSureStu;// ����ѧ����Ϣȷ����ť
	JButton buttonCancel;// ȡ�����Ӱ�ť
	JButton buttonSureCou;// ���ӿγ���Ϣȷ����ť
	JButton buttonStu;// ����ѧ����Ϣ��ť
	JButton buttonCou;// ���ӿγ���Ϣ��ť
	JPanel panel;

	public addWin() {
		setTitle("������Ϣ");
		setBounds(500, 200, 800, 600);
		setVisible(true);
		init();
		setPanelStu();
		item();
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	}

	void initCou() {

		String[][] datas = {};
		String[] titles = { "�γ̴���", "�γ�����", "�γ�����", "��ѧʱ", "ѧ��", "����ѧ��", "ѡ������" };
		model = new DefaultTableModel(datas, titles);
		table = new JTable(model);

	}

	void initStu() {
		String[][] datas = {};
		String[] titles = { "ѧ��", "����", "�Ա�", "����", "ϵ��", "�༶", "��ϵ��ʽ", "��ѡ�γ�" };
		model = new DefaultTableModel(datas, titles);
		table = new JTable(model);
	}

	void init() {
		panel = new JPanel();
		panel.setVisible(true);
		panel.setSize(700, 600);
		this.add(panel);

		String[][] datas = {};
		String[] titles = { "ѧ��", "����", "�Ա�", "����", "ϵ��", "�༶", "��ϵ��ʽ", "��ѡ�γ�" };
		model = new DefaultTableModel(datas, titles);
		table = new JTable(model);

		buttonStu = new JButton("����ѧ����Ϣ");
		buttonCou = new JButton("���ӿγ���Ϣ");
		buttonSureStu = new JButton("ȷ��");
		buttonSureCou = new JButton("ȷ��");
		buttonCancel = new JButton("ȡ��");

	}

	void setPanelStu() {
		TableColumn column = null;
		for (int i = 0; i < 7; i++) {
			column = table.getColumnModel().getColumn(i);
			column.setPreferredWidth(100); 
		}
		model.setRowCount(1);
		panel.add(buttonStu);
		panel.add(buttonCou);

		panel.add(table.getTableHeader());
		panel.add(table);
		panel.add(buttonSureStu);
		panel.add(buttonCancel);
	}

	void setPanelCou() {

		TableColumn column = null;
		for (int i = 0; i < 7; i++) {
			column = table.getColumnModel().getColumn(i);
			column.setPreferredWidth(110); 
		}
		model.setRowCount(1);
		panel.add(buttonStu);
		panel.add(buttonCou);

		panel.add(table.getTableHeader());
		panel.add(table);
		panel.add(buttonSureCou);
		panel.add(buttonCancel);

	}

	void item() {
		buttonStu.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				panel.removeAll();
				initStu();
				setPanelStu();
				panel.updateUI();

			}
		});

		buttonCou.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				panel.removeAll();
				initCou();
				setPanelCou();
				panel.updateUI();

			}
		});

		buttonSureStu.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {

				// TODO Auto-generated method stub
				sql sql = new sql();
				Statement statement = sql.getStatement();
				try {
					table.getValueAt(0, 0).toString().trim();
					if (sql.isPK(table.getValueAt(0, 0).toString().trim())) {
						@SuppressWarnings("unused")
						String str = "insert into stuinfo values(";

						try {
							str += "'" + table.getValueAt(0, 0).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 1).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 2).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 3).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 4).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 5).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 6).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 7).toString().trim() + "'" + ")";
							try {
								statement.executeUpdate(str);
								JOptionPane.showMessageDialog(null, "���ӳɹ���");
								model.getDataVector().clear();
								model.setRowCount(1);
								table.updateUI();
								statement.close();
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

						} catch (NullPointerException e) {
							// TODO Auto-generated catch block
							JOptionPane.showMessageDialog(null, "ȱ����������", "����", JOptionPane.WARNING_MESSAGE);
						}

					} else {
						JOptionPane.showMessageDialog(null, "���������ظ�", "����", JOptionPane.WARNING_MESSAGE);
					}
					
				} catch (NullPointerException e) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, "ȱ������", "����", JOptionPane.WARNING_MESSAGE);
				}
				

			}
		});

		buttonSureCou.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				sql sql = new sql();
				Statement statement = sql.getStatement();
				try {
					table.getValueAt(0, 0).toString().trim();
					if (sql.isPKCou(table.getValueAt(0, 0).toString().trim())) {
						@SuppressWarnings("unused")
						String str = "insert into couinfo values(";

						try {
							str += "'" + table.getValueAt(0, 0).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 1).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 2).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 3).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 4).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 5).toString().trim() + "'" + "," + "'"
									+ table.getValueAt(0, 6).toString().trim() + "'" + ")";
							try {
								statement.executeUpdate(str);
								JOptionPane.showMessageDialog(null, "���ӳɹ���");
								model.getDataVector().clear();
								model.setRowCount(1);
								table.updateUI();
								statement.close();
							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

						} catch (NullPointerException e1) {
							// TODO Auto-generated catch block
							JOptionPane.showMessageDialog(null, "ȱ����������", "����", JOptionPane.WARNING_MESSAGE);
						}

					} else {
						JOptionPane.showMessageDialog(null, "���������ظ�", "����", JOptionPane.WARNING_MESSAGE);
					}
					
				} catch (NullPointerException e1) {
					// TODO: handle exception
					JOptionPane.showMessageDialog(null, "ȱ������", "����", JOptionPane.WARNING_MESSAGE);
				}
			}
		});

		buttonCancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
	}
}
