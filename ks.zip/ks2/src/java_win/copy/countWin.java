package java_win.copy;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class countWin extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	JButton buttonStuNum;
	JButton buttonCouNum;
	JButton buttonCouPel;
	JPanel panel;
	JTable table;
	DefaultTableModel model;

	public countWin() {
		// TODO Auto-generated constructor stub
		setTitle("ͳ��");
		setBounds(500, 200, 800, 600);
		setVisible(true);
		init();
		setpanel();
		count();
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	}

	void tableCouNum() {
		String[][] datas = {};
		String[] titles = { "�γ���", "�γ̴���", "�γ�����", "�γ�����" };
		model = new DefaultTableModel(datas, titles);
		table = new JTable(model);
	}

	void tableCouPel() {
		String[][] datas = {};
		String[] titles = { "�γ̴���", "�γ�����", "�γ�����", "ѡ������" };
		model = new DefaultTableModel(datas, titles);
		table = new JTable(model);
	}

	void tableStuNum() {
		String[][] datas = {};
		String[] titles = { "����", "ѧ��", "����", "�Ա�" };
		model = new DefaultTableModel(datas, titles);
		table = new JTable(model);
	}

	void setpanel() {

		TableColumn column = null;
		for (int i = 0; i < 4; i++) {
			column = table.getColumnModel().getColumn(i);
			column.setPreferredWidth(120);
		}

		panel.add(buttonStuNum);
		panel.add(buttonCouNum);
		panel.add(buttonCouPel);
		buttonCouNum.setSize(20, 20);
		panel.add(table.getTableHeader());
		panel.add(table);

	}

	void init() {
		panel = new JPanel();
		panel.setVisible(true);
		panel.setSize(700, 600);
		this.add(panel);
		buttonCouNum = new JButton("ͳ�ƿγ���");
		buttonCouPel = new JButton("ͳ�ƿγ�ѡ�����");
		buttonStuNum = new JButton("ͳ��ѧ������");
		String[][] datas = {};
		String[] titles = { "����", "ѧ��", "����", "�Ա�" };
		model = new DefaultTableModel(datas, titles);
		table = new JTable(model);

	}

	void count() {
		buttonCouNum.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int i = 0;
				panel.removeAll();
				tableCouNum();
				setpanel();
				panel.updateUI();
				sql sql = new sql();
				Statement statement = sql.getStatement();
				try {
					ResultSet str = statement.executeQuery("select * from couinfo");
					while (str.next()) {
						model.addRow(new String[] { Integer.toString(++i), str.getString("�γ̴���"), str.getString("�γ�����"),
								str.getString("�γ�����") });
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		buttonCouPel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				panel.removeAll();
				tableCouPel();
				setpanel();
				panel.updateUI();
				sql sql = new sql();
				Statement statement = sql.getStatement();
				try {
					ResultSet str = statement.executeQuery("select * from couinfo");
					while (str.next()) {
						model.addRow(new String[] { str.getString("�γ̴���"), str.getString("�γ�����"), str.getString("�γ�����"),
								str.getString("ѡ������") });
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

		buttonStuNum.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int i = 0;
				panel.removeAll();
				tableStuNum();
				setpanel();
				panel.updateUI();
				sql sql = new sql();
				Statement statement = sql.getStatement();
				try {
					ResultSet str = statement.executeQuery("select * from stuinfo");
					while (str.next()) {
						model.addRow(new String[] { Integer.toString(++i), str.getString("ѧ��"), str.getString("����"),
								str.getString("�Ա�") });
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
	}

}
