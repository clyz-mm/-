package java_win.copy;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class importWin extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// EXEC master..xp_cmdshell 'bcp student..stuinfo in "F:\kk.txt" -c -S"(local)"
	// -t'
	JLabel labelFile;
	JTextField textField;
	JButton buttonFile;
	JButton buttonImport;
	JButton buttonCancel;
	JButton buttonImportCou;

	public importWin() {
		// TODO Auto-generated constructor stub
		setTitle("�����ļ�");
		setBounds(500, 200, 800, 600);
		setVisible(true);
		init();
		importFile();
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	}

	void init() {
		setLayout(new FlowLayout());
		labelFile = new JLabel("������������ťѡ��Ҫ�ϴ����ļ���");
		textField = new JTextField(40);
		buttonFile = new JButton("���");
		buttonImport = new JButton("�ϴ�ѧ����Ϣ");
		buttonImportCou = new JButton("�ϴ��γ���Ϣ");
		buttonCancel = new JButton("ȡ��");

		add(labelFile);
		add(textField);
		add(buttonFile);
		add(buttonImport);
		add(buttonImportCou);
		add(buttonCancel);
	}

	void importFile() {

		buttonFile.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				String path = new FileChooserWin().getOpenPath();
				textField.setText(path);
			}
		});

		buttonImport.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				sql sql = new sql();
				Statement statement = sql.getStatement();
				char[] path = textField.getText().toCharArray();
				String newpath = "";
				for (int i = 0; i < path.length; i++) {

					if (path[i] == '\\') {
						newpath += "\\\\";
					} else {
						newpath += path[i];
					}
				}
				System.out.println(newpath);
				String Import = "EXEC xp_cmdshell 'bcp student..stuinfo in lj -c -S\"(local)\" -T'";
				try {
					String sqlIn = Import.replaceAll("lj", newpath);
					System.out.println("�滻�ɹ�");
					System.out.println(sqlIn);
					try {
						statement.execute(sqlIn);
						JOptionPane.showMessageDialog(null, "����ɹ�", "��ʾ", JOptionPane.WARNING_MESSAGE);
					} catch (SQLException e2) {
						// TODO: handle exception
						JOptionPane.showMessageDialog(null, "����ʧ�ܣ�ǰ��������Ƿ��ظ�", "��ʾ", JOptionPane.WARNING_MESSAGE);
					}

				} catch (Exception e2) {
					// TODO: handle exception
					System.err.println("�滻ʧ��");
				}

			}
		});

		buttonImportCou.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				sql sql = new sql();
				Statement statement = sql.getStatement();
				char[] path = textField.getText().toCharArray();
				String newpath = "";
				for (int i = 0; i < path.length; i++) {

					if (path[i] == '\\') {
						newpath += "\\\\";
					} else {
						newpath += path[i];
					}
				}
				System.out.println(newpath);
				String Import = "EXEC xp_cmdshell 'bcp student..couinfo in lj -c -S\"(local)\" -T'";
				try {
					String sqlIn = Import.replaceAll("lj", newpath);
					System.out.println("�滻�ɹ�");
					System.out.println(sqlIn);
					try {
						statement.execute(sqlIn);
						JOptionPane.showMessageDialog(null, "����ɹ�", "��ʾ", JOptionPane.WARNING_MESSAGE);
					} catch (SQLException e2) {
						// TODO: handle exception
						JOptionPane.showMessageDialog(null, "����ʧ�ܣ�ǰ��������Ƿ��ظ�", "��ʾ", JOptionPane.WARNING_MESSAGE);
					}

				} catch (Exception e2) {
					// TODO: handle exception
					System.err.println("�滻ʧ��");
				}

			}
		});

		buttonCancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
	}
}
