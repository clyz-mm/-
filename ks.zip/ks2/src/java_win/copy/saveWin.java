package java_win.copy;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class saveWin extends showWin {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// EXEC xp_cmdshell 'bcp "select * from student..stuinfo" queryout "f:\1.xls" -c
	// -S"(local)" -T'
	// EXEC xp_cmdshell 'bcp "select * from student..couinfo" queryout "f:\1.xls" -c
	// -S"(local)" -T'
	JButton buttonView;

	public saveWin() {
		// TODO Auto-generated constructor stub
		setTitle("������Ϣ");
	}

	void cha() {// ��д���෽��
		labelDelCou = new JLabel("����������ѡ���ļ������·����");
		buttonView = new JButton("���");
		buttonDelCou = new JButton("����γ���Ϣ");
		buttonDelStu = new JButton("����ѧ����Ϣ");
		textDelCou = new JTextField(25);// ·��
		add(labelDelCou);
		add(textDelCou);
		add(buttonView);
		add(buttonDelStu);
		add(buttonDelCou);
	}

	void deleteOrSave() {// ��д���෽��

		buttonView.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String path = new FileChooserWin().getSavePath();
				textDelCou.setText(path);
			}
		});

		buttonDelCou.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if (j != 0) {
					String strCou = "EXEC xp_cmdshell 'bcp \"select * from student..couinfo\" queryout \"lj\" -c -S\"(local)\" -T'";
					char[] path = textDelCou.getText().toCharArray();
					String newpath = "";
					for (int i = 0; i < path.length; i++) {

						if (path[i] == '\\') {
							newpath += "\\\\";
						} else {
							newpath += path[i];
						}
					}
					try {
						String sqlSave = strCou.replaceAll("lj", newpath);
						System.out.println("�滻�ɹ�");
						sql sql = new sql();
						Statement statement = sql.getStatement();
						try {
							statement.execute(sqlSave);
							JOptionPane.showMessageDialog(null, "�����ɹ�", "��ʾ", JOptionPane.WARNING_MESSAGE);
						} catch (Exception e) {
							// TODO: handle exception
							System.err.println("��������");
						}

						// System.out.println(sqlSave);
					} catch (Exception e) {
						// TODO: handle exception
						System.err.println("�滻ʧ��");
					}
				} else {
					JOptionPane.showMessageDialog(null, "��¼Ϊ�գ�����ʧ��", "��ʾ", JOptionPane.WARNING_MESSAGE);
				}
			}
		});

		buttonDelStu.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (i != 0) {
					String strCou = "EXEC xp_cmdshell 'bcp \"select * from student..stuinfo\" queryout \"lj\" -c -S\"(local)\" -T'";
					char[] path = textDelCou.getText().toCharArray();
					String newpath = "";
					for (int i = 0; i < path.length; i++) {

						if (path[i] == '\\') {
							newpath += "\\\\";
						} else {
							newpath += path[i];
						}
					}
					try {
						String sqlSave = strCou.replaceAll("lj", newpath);
						sql sql = new sql();
						Statement statement = sql.getStatement();
						try {
							statement.execute(sqlSave);
							JOptionPane.showMessageDialog(null, "�����ɹ�", "��ʾ", JOptionPane.WARNING_MESSAGE);
						} catch (Exception e1) {
							// TODO: handle exception
							System.err.println("��������");
						}

						// System.out.println(sqlSave);
					} catch (Exception e1) {
						// TODO: handle exception
						System.err.println("�滻ʧ��");
					}
				} else {
					JOptionPane.showMessageDialog(null, "��¼Ϊ�գ�����ʧ��", "��ʾ", JOptionPane.WARNING_MESSAGE);
				}

			}
		});
	}
}
