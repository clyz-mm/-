package java_win.copy;

import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class searchWin extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	JButton buttonStu;
	JButton buttonCou;
	JButton buttonSureStu;
	JButton buttonSureCou;
	JButton buttonCancel;
	JButton buttonEditStu;///
	JButton buttonEditCou;

	JTextField textFieldIn;

	JTable tableOut = null;
	DefaultTableModel model = null;

	JLabel label;
	JPanel panel;
	String num;

	public searchWin() {
		// TODO Auto-generated constructor stub
		setTitle("��ѯ\\�༭");
		setBounds(500, 200, 800, 600);
		setVisible(true);
		init();
		setPanelStu();
		item();
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	}

	void initCou() {
		String[][] datas = {};
		String[] titles = { "�γ̴���", "�γ�����", "�γ�����", "��ѧʱ", "ѧ��", "����ѧ��", "ѡ������" };
		model = new DefaultTableModel(datas, titles);
		tableOut = new JTable(model);
		label = new JLabel("������γ̴�����в�ѯ��");
	}

	void initStu() {
		String[][] datas = {};
		String[] titles = { "ѧ��", "����", "�Ա�", "����", "ϵ��", "�༶", "��ϵ��ʽ", "��ѡ�γ�" };
		model = new DefaultTableModel(datas, titles);
		tableOut = new JTable(model);
		label = new JLabel("������ѧ�Ž��в�ѯ��");
	}

	void init() {

		panel = new JPanel();
		panel.setSize(700, 600);
		panel.setVisible(true);
		this.add(panel);

		String[][] datas = {};
		String[] titles = { "ѧ��", "����", "�Ա�", "����", "ϵ��", "�༶", "��ϵ��ʽ", "��ѡ�γ�" };
		model = new DefaultTableModel(datas, titles);
		tableOut = new JTable(model);

		label = new JLabel("������ѧ�Ž��в�ѯ��");
		buttonCancel = new JButton("ȡ��");
		buttonSureStu = new JButton("ȷ��");
		buttonSureCou = new JButton("ȷ��");
		buttonStu = new JButton("��ѯѧ����Ϣ");
		buttonCou = new JButton("��ѯ�γ���Ϣ");
		buttonEditStu = new JButton("ȷ���޸�");
		buttonEditCou = new JButton("ȷ���޸�");

		textFieldIn = new JTextField(10);
	}

	void setPanelStu() {

		TableColumn column = null;
		for (int i = 0; i < 7; i++) {
			column = tableOut.getColumnModel().getColumn(i);
			column.setPreferredWidth(100);
		}

		panel.add(buttonStu);
		panel.add(buttonCou);
		panel.add(label);
		panel.add(textFieldIn);

		panel.add(buttonSureStu);
		panel.add(buttonCancel);
		panel.add(tableOut.getTableHeader());
		panel.add(tableOut);
		panel.add(buttonEditStu);

	}

	void setPanelCou() {
		TableColumn column = null;
		for (int i = 0; i < 7; i++) {
			column = tableOut.getColumnModel().getColumn(i);
			column.setPreferredWidth(100);
		}

		panel.add(buttonStu);
		panel.add(buttonCou);
		panel.add(label);
		panel.add(textFieldIn);

		panel.add(buttonSureCou);
		panel.add(buttonCancel);
		panel.add(tableOut.getTableHeader());
		panel.add(tableOut);
		panel.add(buttonEditCou);

	}

	void item() {
		buttonStu.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				panel.removeAll();
				initStu();
				setPanelStu();
				panel.updateUI();

			}
		});

		buttonCou.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				panel.removeAll();
				initCou();
				setPanelCou();
				panel.updateUI();

			}
		});

		buttonSureStu.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				sql sql = new sql();
				num = textFieldIn.getText().toString().trim();
				if (!sql.isPK(num)) {
					try {
						Statement statement = sql.getStatement();
						ResultSet str = statement.executeQuery("select * from stuinfo");
						System.out.println("��ѯ�ɹ�");
						while (str.next()) {
							if (str.getString("ѧ��").trim().equals(num)) {
								model.setRowCount(0);
								model.addRow(new String[] { str.getString("ѧ��"), str.getString("����"),
										str.getString("�Ա�"), str.getString("����"), str.getString("ϵ��"),
										str.getString("�༶"), str.getString("��ϵ��ʽ"), str.getString("��ѡ�γ�") });
							}

						}

					} catch (SQLException e) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null, "��ѯ����", "��ʾ", JOptionPane.WARNING_MESSAGE);
					}

				} else {
					model.setRowCount(0);
					JOptionPane.showMessageDialog(null, "���޴˼�¼", "��ʾ", JOptionPane.WARNING_MESSAGE);
				}

			}
		});

		buttonSureCou.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				sql sql = new sql();
				num = textFieldIn.getText().toString().trim();
				if (!sql.isPKCou(num)) {
					try {
						Statement statement = sql.getStatement();
						ResultSet str = statement.executeQuery("select * from couinfo");
						System.out.println("��ѯ�ɹ�");
						while (str.next()) {
							if (str.getString("�γ̴���").trim().equals(num)) {
								model.setRowCount(0);
								model.addRow(new String[] { str.getString("�γ̴���"), str.getString("�γ�����"),
										str.getString("�γ�����"), str.getString("��ѧʱ"), str.getString("ѧ��"),
										str.getString("����ѧ��"), str.getString("ѡ������") });
							}

						}

					} catch (SQLException e) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null, "��ѯ����", "��ʾ", JOptionPane.WARNING_MESSAGE);
					}

				} else {
					model.setRowCount(0);
					JOptionPane.showMessageDialog(null, "���޴˼�¼", "��ʾ", JOptionPane.WARNING_MESSAGE);
				}
			}
		});

		buttonEditStu.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				sql sql = new sql();
				String del = "delete from stuinfo where ѧ��=";
				String update = "insert into stuinfo values(";
				Statement statement = sql.getStatement();

				if (!num.equals(tableOut.getValueAt(0, 0).toString().trim())) {
					if (sql.isPK(tableOut.getValueAt(0, 0).toString().trim())) {
						del += "'" + num + "'";
						try {
							statement.executeUpdate(del);
							System.out.println("ɾ���ɹ�");
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							System.err.println("ɾ��ʧ��");
						}
						update += "'" + tableOut.getValueAt(0, 0).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 1).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 2).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 3).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 4).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 5).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 6).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 7).toString().trim() + "'" + ")";
						try {
							statement.executeUpdate(update);
							JOptionPane.showMessageDialog(null, "�޸ĳɹ�", "��ʾ", JOptionPane.WARNING_MESSAGE);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							System.err.println("�޸�ʧ��");
						}

					} else {
						JOptionPane.showMessageDialog(null, "��Ϣ�ظ�,�޸�ʧ��", "��ʾ", JOptionPane.WARNING_MESSAGE);
					}
				} else {
					del += "'" + num + "'";
					try {
						statement.executeUpdate(del);
						System.out.println("ɾ���ɹ�");
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						System.err.println("ɾ��ʧ��");
					}
					update += "'" + num + "'" + "," + "'" + tableOut.getValueAt(0, 1).toString().trim() + "'" + ","
							+ "'" + tableOut.getValueAt(0, 2).toString().trim() + "'" + "," + "'"
							+ tableOut.getValueAt(0, 3).toString().trim() + "'" + "," + "'"
							+ tableOut.getValueAt(0, 4).toString().trim() + "'" + "," + "'"
							+ tableOut.getValueAt(0, 5).toString().trim() + "'" + "," + "'"
							+ tableOut.getValueAt(0, 6).toString().trim() + "'" + "," + "'"
							+ tableOut.getValueAt(0, 7).toString().trim() + "'" + ")";
					try {
						statement.executeUpdate(update);
						JOptionPane.showMessageDialog(null, "�޸ĳɹ�", "��ʾ", JOptionPane.WARNING_MESSAGE);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						System.err.println("�޸�ʧ��");
					}

				}
			}
		});

		buttonEditCou.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				sql sql = new sql();
				String del = "delete from couinfo where �γ̴���=";
				String update = "insert into couinfo values(";
				Statement statement = sql.getStatement();

				if (!num.equals(tableOut.getValueAt(0, 0).toString().trim())) {
					if (sql.isPKCou(tableOut.getValueAt(0, 0).toString().trim())) {
						del += "'" + num + "'";
						try {
							statement.executeUpdate(del);
							System.out.println("ɾ���ɹ�");
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							System.err.println("ɾ��ʧ��");
						}
						update += "'" + tableOut.getValueAt(0, 0).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 1).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 2).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 3).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 4).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 5).toString().trim() + "'" + "," + "'"
								+ tableOut.getValueAt(0, 6).toString().trim() + "'" + ")";
						try {
							statement.executeUpdate(update);
							JOptionPane.showMessageDialog(null, "�޸ĳɹ�", "��ʾ", JOptionPane.WARNING_MESSAGE);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							System.err.println("�޸�ʧ��");
						}

					} else {
						JOptionPane.showMessageDialog(null, "��Ϣ�ظ�,�޸�ʧ��", "��ʾ", JOptionPane.WARNING_MESSAGE);
					}
				} else {
					del += "'" + num + "'";
					try {
						statement.executeUpdate(del);
						System.out.println("ɾ���ɹ�");
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						System.err.println("ɾ��ʧ��");
					}
					update += "'" + num + "'" + "," + "'" + tableOut.getValueAt(0, 1).toString().trim() + "'" + ","
							+ "'" + tableOut.getValueAt(0, 2).toString().trim() + "'" + "," + "'"
							+ tableOut.getValueAt(0, 3).toString().trim() + "'" + "," + "'"
							+ tableOut.getValueAt(0, 4).toString().trim() + "'" + "," + "'"
							+ tableOut.getValueAt(0, 5).toString().trim() + "'" + "," + "'"
							+ tableOut.getValueAt(0, 6).toString().trim() + "'" + ")";
					try {
						statement.executeUpdate(update);
						JOptionPane.showMessageDialog(null, "�޸ĳɹ�", "��ʾ", JOptionPane.WARNING_MESSAGE);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						System.err.println("�޸�ʧ��");
					}

				}

			}
		});

		buttonCancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				dispose();
			}
		});
	}

}
